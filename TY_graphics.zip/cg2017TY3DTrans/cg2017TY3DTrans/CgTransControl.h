#pragma once


#define N
#include "TypeDefine.h"
#include "cg2017TY3DTransDoc.h"

// CCgTransControl ������ͼ
#define  NN 64
#define PRJPLANERETWIDTH  400
#define PRJPLANERETHEIGHT 400


class CCgTransControl : public CFormView
{
	DECLARE_DYNCREATE(CCgTransControl)

protected:
	CCgTransControl();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
	virtual ~CCgTransControl();

public:
	enum { IDD = IDD_TRANSCONTROL };
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	
	int m_transSelect;
	afx_msg void OnSelchangeTransselect();
	afx_msg void OnClickedXleft();
	afx_msg void OnClickedXright();
	afx_msg void OnClickedYup();
	afx_msg void OnClickedYdown();
	afx_msg void OnClickedZfront();
	afx_msg void OnClickedZback();
	afx_msg void OnClickedTransmode();
	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
private:
	int      m_objNumber;
	Object_p m_whoObject;           // Object pointer
	COLORREF vcObjColor[SPACEOBJECTS];

	int polyCount;
	float ymax[NN],ymin[NN];
	int ibegin,iend,scan,pdges;
	float Dx[NN],Xa[NN],Sc[NN],Dc[NN];

	float prjPlaneRetZ[PRJPLANERETWIDTH][PRJPLANERETHEIGHT];  // Z-Buffer 2D Array

	void pTransToZbuffer(CRect dcRect);
	void pDrawLineObject(CDC *pDC, CRect dcRect);
	void pDrawLightObject(CDC *pDC, CRect dcRect, float maxShade, float minShade);
	void pDrawShadeLightObject(CDC *pDC, CRect dcRect, float maxShade, float minShade);

	void FillPolygon(CDC *pDC, int n,int *x,int *y,int *color,CRect dcRect);
	void Loadpolygon(int n,int *x,int *y, int *color);
	void PolyInsert(float x1,float y1,float x2,float y2, int c1, int c2);
	void UpdateXvalue();
	void XSort(int begin,int i);
	void Fillscan(CDC *pDC,CRect dcRect);
	void Include();

	// Interface for remove hidden part by Z-buffer Method. 
	float CalculateZValue(int x,int y,CRect dcRect,int i);
};


