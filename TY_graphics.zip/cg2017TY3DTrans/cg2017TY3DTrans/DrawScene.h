#pragma once

#include "TypeDefine.h"
#include "cg2017TY3DTransDoc.h"
#include "cg2017TY3DTransView.h"

class CDrawScene
{
public:
	CDrawScene(void);
	~CDrawScene(void);
	CDrawScene(Ccg2017TY3DTransView* pView);

	void DrawScene();

private:
	int      m_objNumber;
	Object_p m_whoObject;           // Object pointer
	Ccg2017TY3DTransView* m_pView;
	float glObjColor[SPACEOBJECTS][3];

	//	float xCenter,yCenter,zCenter;

	void CaculateMatrix();
	void DrawBackground();
	void DrawSpaceObject();
	void TransSpaceObject();

	void projectSpaceObject();

	void rotateX3Dmatrix(float S, float C);
	void rotateY3Dmatrix(float S, float C);
	void rotateZ3Dmatrix(float S, float C);

private:
	void translate3dMatrix(float dx, float dy, float dz);

private:
	void pRemoveBackFace();
	// 
	void pClipSpaceObject();
	int pVisible(float x, float y, float z, int pane);
	int outPut(float x, float y, float z, int *outCount, Gpoint_p polyClip);
	int pLineCrossPane(float sx, float sy, float sz,
		float px, float py, float pz, int pane);
	int pLineInterSectPane(float sx, float sy, float sz, 
		float px, float py, float pz,
		int pane, int *outCount, Gpoint_p polyClip);
	// 
	void pObjectCenter();
	void pLightSpaceBall();
	void pLightSpaceObject();
	float xCenter,yCenter,zCenter;

};

